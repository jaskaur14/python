class BankAccount:
    # don't forget to add some default values for these parameters!
    balance = 1000
    int_rate = 0.01
    def __init__(self, int_rate, balance): 
        self.int_rate = int_rate
        self.balance = balance
        # (remember, instance attributes go here)
        
    def deposit(self, amount):
        self.amount = amount
        self.balance += amount
        return self
        
    def withdraw(self, amount):
        self.amount = amount
        if amount <= self.balance:
            self.balance -= amount
            print(self.balance)
        else:
            print("insufficient funds: Charging a $5 fee")
            self.balance -= 5
            return self
        
    def display_account_info(self):
        print (f"Current Balance: {self.balance}")
        return self
        # your code here
    def yield_interest(self):
        self.balance = (self.balance * int_rate) + self.balance
        return self
        # your code here
checking = BankAccount()
checking.deposit
checking.withdraw
checking.display_account_info
checking.yield_interest

#not sure what to do after this/stuck
#line 33 error
# TypeError: BankAccount.__init__() missing 2 required positional arguments: 'int_rate' and 'balance'