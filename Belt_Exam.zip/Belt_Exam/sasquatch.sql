SELECT * FROM sasquatch.users;
-- INSERT INTO sasquatch.users (first_name, last_name, email, password)
-- VALUES ("jasleen", "kaur", "jas@jas.com", "peanuts123")
